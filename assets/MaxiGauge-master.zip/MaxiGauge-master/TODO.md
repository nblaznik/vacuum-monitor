* Use [Cubism](http://square.github.com/cubism/) for data visualization.

### References

* <http://stackoverflow.com/questions/10747433/can-we-use-custom-json-data-on-cubism>
* <http://stackoverflow.com/questions/10526058/using-other-data-sources-for-cubism-js>
